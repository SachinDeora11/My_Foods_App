import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'npcegap4',
    dataset: 'production'
  }
})
